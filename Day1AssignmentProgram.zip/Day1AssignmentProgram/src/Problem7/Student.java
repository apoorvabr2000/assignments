package Problem7;

public class Student {

}
