package Problem1;
import java.util.Scanner;
public class Project1 {

	public static void main(String[] args) {
		int n;
		Scanner x= new Scanner(System.in);
		System.out.println("Enter the value of n :");
		n=x.nextInt();
		for(int i=0;i<=n;i++) {
			if(i%2==0)
				System.out.println(i +" ");
		}
        
	}

}
